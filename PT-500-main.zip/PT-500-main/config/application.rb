require_relative "boot"
require_relative "../lib/clerk_upload_handshake"

require "rails"
# Pick the frameworks you want:
require "active_model/railtie"
require "active_job/railtie"
require "active_record/railtie"
require "active_storage/engine"
require "action_controller/railtie"
require "action_mailer/railtie"
require "action_mailbox/engine"
require "action_text/engine"
require "action_view/railtie"
require "action_cable/engine"
# require "rails/test_unit/railtie"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

# json 3.0 made JSON.parse keyword-only. Rails 8.1 still passes a positional options Hash
# when decoding encrypted session cookies, which is how flash notices survive a redirect.
require "json"
unless JSON.respond_to?(:__rails_json3_parse)
  class << JSON
    alias_method :__rails_json3_parse, :parse

    def parse(source, opts = nil, **kwargs)
      options = kwargs
      options = opts.merge(kwargs) if opts.is_a?(Hash)
      __rails_json3_parse(source, **options)
    end
  end
end

module PtSociety
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 8.1
    config.middleware.insert_before 0, ClerkUploadHandshake

    # Please, add to the `ignore` list any other `lib` subdirectories that do
    # not contain `.rb` files, or that should not be reloaded or eager loaded.
    # Common ones are `templates`, `generators`, or `middleware`, for example.
    config.autoload_lib(ignore: %w[assets tasks])

    # Configuration for the application, engines, and railties goes here.
    #
    # These settings can be overridden in specific environments using the files
    # in config/environments, which are processed later.
    #
    config.time_zone = "Central Time (US & Canada)"
    # config.eager_load_paths << Rails.root.join("extras")

    config.generators do |g|
      g.test_framework :rspec, fixtures: false
      g.system_tests = nil
    end
  end
end
